<?php
session_start();
$servername = "localhost:3306";
$username = "krcgrwhu";
$password = "EzY2KRuspgwF9U";
$bdd = new PDO("mysql:host=$servername;dbname=krcgrwhu_sonovibes", $username, $password);
$bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//Se connecte à la bdd
// Vérifie si le formulaire a été soumis
if ($_SERVER["REQUEST_METHOD"] === "POST") {    // Vérifie quelle action a été effectuée
    if (isset($_POST["action"])) {
        $action = $_POST["action"];
        //$questionajouterfaq = 
        //$rajouterajouterfaq =

        // En fonction de l'action, effectuez les actions nécessaires
        switch ($action) {
            case "supprimer_faq":
                if (isset($_POST["id_faq"])) {
                    $id_faq = $_POST["id_faq"];
                    // Code pour supprimer la FAQ avec l'ID $faqId




                    $stmt = $bdd->prepare("DELETE FROM gerer_faq WHERE id_faq = :id_faq");
                    $stmt->bindParam(':id_faq', $id_faq, PDO::PARAM_INT); 
                    $stmt->execute();

                    echo'suppfaq '.$id_faq.'';
                    header("Location: admin_faq.php");
                    exit;
                }
                break;

            case "changer_question":
                if (isset($_POST["id_faq"])) {
                    $id_faq = $_POST["id_faq"];
                    // Code pour changer la question de la FAQ avec l'ID $faqId
                    echo'questionfaq '.$id_faq.'';
                }
                break;

            case "changer_reponse":
                if (isset($_POST["id_faq"])) {
                    $id_faq = $_POST["id_faq"];
                    // Code pour changer la réponse de la FAQ avec l'ID $faqId
                    echo'reponsefaq'.$id_faq.'';
                }
                break;

            case "ajouter_faq":
                // Code pour ajouter une nouvelle FAQ
                echo'ajouterfaq de utilisateur '.$_SESSION['id_utilisateur'].'';
                $question = $_POST['questionajouterfaq'];
                $reponse = $_POST['reponseajouterfaq'];
                $stmt = $bdd->prepare("INSERT INTO gerer_faq (question, reponse, id_utilisateur) VALUES (:question, :reponse, :id_utilisateur)");
                $stmt->bindParam(':question', $question, PDO::PARAM_STR); 
                $stmt->bindParam(':reponse', $reponse, PDO::PARAM_STR);  
                $stmt->bindParam(':id_utilisateur', $_SESSION['id_utilisateur'], PDO::PARAM_INT);
                $stmt->execute();
                $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                header("Location: admin_faq.php");
                exit();
                break;

            // Autres actions si nécessaire
        }
    }
}
?>
