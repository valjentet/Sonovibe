<?php
session_start();

    $servername = "localhost:3306";
    $username = "krcgrwhu";
    $password = "EzY2KRuspgwF9U";
    $bdd = new PDO("mysql:host=$servername;dbname=krcgrwhu_sonovibes", $username, $password);
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);





$bdd = new PDO("mysql:host=$servername;dbname=krcgrwhu_sonovibes", $username, $password);
$bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stmt = $bdd->prepare("SELECT * FROM gerer_faq WHERE id_utilisateur = :id_utilisateur");
$stmt->bindParam(':id_utilisateur', $_SESSION['id_utilisateur'], PDO::PARAM_INT); 
$stmt->execute();
$result = $stmt->fetchALL(PDO::FETCH_ASSOC);


?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="css/sidebar_admin.css" />
    <link rel="stylesheet" type="text/css" href="css/gestion_faq.css">
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.0.0/uicons-solid-rounded/css/uicons-solid-rounded.css'>
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.0.0/uicons-bold-rounded/css/uicons-bold-rounded.css'>
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.0.0/uicons-regular-rounded/css/uicons-regular-rounded.css'>
    <title>Bienvenue</title>
</head>
<body>
    <div class="sidebar">
        <div class="logo">
        <img src="../Images/Sonovibes_logo.png" alt="Logo Sonovibes">
        </div>
        <ul>
            <li><i class="fi fi-br-house-chimney icon" class="test"></i><a href="dashboard_admin.php">Dashboard</a></li>
            <li><i class="fi fi-br-waveform-path icon"></i><a href="event_create.php">Evenements</a></li>
            <li><i class="fi fi-br-sensor-on icon"></i><a href="capteur_sonore.php">Données capteurs</a></li>
        </ul>
        <ul>
            <div class="admin_gest">
                <div class="sidebar-title">Administration</div>
                <li><i class="fi fi-br-user icon"></i><a href="admin_faq.php">Gestion FAQ</a></li>
                <li><i class="fi fi-br-heart icon"></i><a href="admin_commentaires.php">Gestion des Commentaires</a></li>
                <li><i class="fi fi-br-sign-out-alt icon"></i><a href="admin_moderation.php">Gestion de Membres</a></li>
            </div>
        </ul>
        <ul>
            <div class="profil">
                <div class="sidebar-title">Votre compte</div>
                <li><i class="fi fi-br-user icon"></i><a href="#">Mon profil</a></li>
                <li><i class="fi fi-br-sign-out-alt icon"></i><a href="../logout.php">Déconnexion</a></li>
            </div>
        </ul>
    </div>

    <div class="content">
        <div class="faq-list">

            <div class="faq-container">
                <h1>Foire Aux Questions</h1>
                                                        <!--Gestion des boutons et de l'affichage -->
                <?php foreach ($result as $faq) { ?>
                    <div class="faq-item">
                        <h2 class="question">
                        Question : <?php echo $faq['question']; ?>
                            <form method="POST" action="modifier_faq.php">
                            <input type="hidden" name="id_faq" value="<?php echo $faq['id_faq']; ?>">
                            <button type="submit" name="action" value="supprimer_faq" class="buttonfaq3">Supprimer la FAQ</button>
                            </form>


                        </h2>
                        <p class="answer">
                            Réponse : <?php echo $faq['reponse']; ?>
                        </p>
                    </div>








<div id="popupquestionfaq" class="popupquestionfaq">
    <div class="popupquestionfaq2">
        <h2>Créer une Question-Réponse :</h2>
        <form  action="modifier_faq.php" method="post" enctype="multipart/form-data">
        <span onclick="fermerPopup()" >&times;</span>
        <input type="hidden" name="action" value="ajouter_faq">
            <label for="questionajouterfaq">Question :</label>
            <input type="text" required>

            <label for="reponseajouterfaq">Réponse :</label>
            <input type="text" required></input>

            <input  type="submit" name="submit_faq" value="Ajouter une FAQ">
            <button  type="button" onclick="fermerPopup()">Fermer</button>
        </form>
        <script>
            // Fonction pour afficher la fenêtre pop-up
            function afficherPopup() {
                document.getElementById("popupquestionfaq").style.display = "block";
            }

            // Fonction pour fermer la fenêtre pop-up
            function fermerPopup() {
                document.getElementById("popupquestionfaq").style.display = "none";
            }

            // Associer la fonction à l'événement click du bouton
            document.getElementById("boutonajouterfaq").addEventListener("click", afficherPopup);
        </script>


    </div>
</div>




















  
                <?php } ?>

            </div>

        </div>
        <button id="boutonajouterfaq"  class="buttonfaq">Ajouter FAQ</button>
 
    </div>



    <!-- Formulaire dans la popup -->
<div id="popupContainerajouterfaq" class="popup-containerfaq">
    <div class="popup-contentfaq">
        <h2>Créer une Question-Réponse :</h2>
        <form  action="modifier_faq.php" method="post" enctype="multipart/form-data">
        <span onclick="fermerPopup()" class="closeajouterfaq">&times;</span>
        <input type="hidden" name="action" value="ajouter_faq">
            <label for="questionajouterfaq">Question :</label>
            <input type="text" name="questionajouterfaq"  required>

            <label for="reponseajouterfaq">Réponse :</label>
            <input type="text" name="reponseajouterfaq"  required></input>

            <input class="boutoncentrerajouterfaq" type="submit" name="submit_faq" value="Ajouter une FAQ">
            <button class="boutoncentrerajouterfaq" type="button" onclick="fermerPopup()">Fermer</button>
        </form>

        <script>
            // Fonction pour afficher la fenêtre pop-up
            function afficherPopup() {
                document.getElementById("popupContainerajouterfaq").style.display = "block";
            }

            // Fonction pour fermer la fenêtre pop-up
            function fermerPopup() {
                document.getElementById("popupContainerajouterfaq").style.display = "none";
            }

            // Associer la fonction à l'événement click du bouton
            document.getElementById("boutonajouterfaq").addEventListener("click", afficherPopup);
        </script>

    </div>
</div>




</body>
</html>
