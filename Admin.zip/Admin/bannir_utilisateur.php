<?php
session_start();


if (isset($_GET['id'])) {
    $user_id_to_delete = $_GET['id'];
    $deleteFaqQuery = "DELETE FROM faq WHERE id_utilisateur = ?";
    $stmtFaq = $conn->prepare($deleteFaqQuery);
    if ($stmtFaq) {
        $stmtFaq->bind_param("i", $user_id_to_delete);
        $stmtFaq->execute();
        $stmtFaq->close();
    } else {
        echo "Erreur lors de la préparation de la requête.";
    }
    $deleteUserQuery = "DELETE FROM users WHERE id_utilisateur = ?";
    $stmtUser = $conn->prepare($deleteUserQuery);
    if ($stmtUser) {
        $stmtUser->bind_param("i", $user_id_to_delete);
        $stmtUser->execute();
        $stmtUser->close();
        header("Location: admin_faq.php");
        exit();
    } else {
        echo "Erreur lors de la préparation de la requête.";
    }
} else {
    header("Location: admin_faq.php");
    exit();
}
$conn->close();
?>
