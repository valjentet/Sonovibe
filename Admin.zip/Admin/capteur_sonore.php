<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Courbe Sonore Détaillée</title>
    <!-- Inclure la bibliothèque Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 90%;
        }

        canvas {
            max-width: 100%;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <canvas id="soundCurve"></canvas>

    <script>
        // Générer des données pour une courbe plus détaillée
        var data = [];
        for (var i = 0; i <= 100; i++) {
            data.push(Math.sin(i * 0.1) * 50 + 50); // Utilisation d'une fonction sinus pour créer une courbe
        }

        // Configuration du graphique de type "line"
        var ctx = document.getElementById('soundCurve').getContext('2d');
        var soundCurve = new Chart(ctx, {
            type: 'line',
            data: {
                labels: Array.from({ length: 101 }, (_, i) => i.toString()), // Labels de 0 à 100
                datasets: [{
                    label: 'Courbe Sonore Détaillée',
                    data: data,
                    borderColor: '#e74c3c',
                    borderWidth: 2,
                    fill: false
                }]
            },
            options: {
                scales: {
                    x: {
                        type: 'linear',
                        position: 'bottom'
                    },
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    </script>
</body>
</html>
