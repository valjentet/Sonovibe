<?php

session_start();
$servername="localhost:3306";
$username="krcgrwhu";
$password="EzY2KRuspgwF9U";





try {
    $bdd = new PDO("mysql:host=$servername;dbname=krcgrwhu_sonovibes", $username, $password);
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Erreur : " . $e->getMessage();
}







if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email_utilisateur = $_POST['email'];
    $roles = $_POST['adminRole'];
    $id_participant = $_SESSION['id_participant'];



        // Préparez et exécutez la requête SQL
        $stmt = $bdd->prepare("SELECT email_utilisateur FROM utilisateur WHERE email_utilisateur = :emailToCheck");
        $stmt->bindParam(':emailToCheck', $email_utilisateur, PDO::PARAM_STR);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $stmt = $bdd->prepare("SELECT email_participant FROM participant WHERE email_participant = :emailToCheck");
        $stmt->bindParam(':emailToCheck', $email_utilisateur, PDO::PARAM_STR);
        $stmt->execute();
        $result2 = $stmt->fetch(PDO::FETCH_ASSOC);

        // Vérifiez si l'email existe déjà
    if ($result) {
        
        $stmt = $bdd->prepare("UPDATE utilisateur SET roles = :roles  WHERE email_utilisateur = :email_utilisateur");
        $stmt->bindParam(':roles', $roles, PDO::PARAM_STR);
        $stmt->bindParam(':email_utilisateur', $email_utilisateur, PDO::PARAM_STR);
        $stmt->execute();
            
        }
     elseif ($result2) {

            $requete = $bdd->prepare("INSERT INTO utilisateur VALUES (0, :roles, :email_utilisateur, :id_participant)");
            $requete->execute(
            array(
                'roles' => $roles,
                'email_utilisateur' => $email_utilisateur,
                'id_participant' => $id_participant,      )
        );
    }
    
}

?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href=gestion_faq.css>
    <title>Ajouter un Modérateur</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .form-container {
            width: 40vw;
            height: 70vh; 
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 2vh 2vw;
            box-sizing: border-box;
        }

        .form-container label {
            display: block;
            margin-bottom: 8px;
        }

        .form-container input {
            width: 100%;
            padding: 8px;
            margin-bottom: 16px;
            box-sizing: border-box;
        }

        .form-container button {
            width: 100%;
            padding: 10px;
            background-color: #3498db;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .note {
            font-size:1.1em ;
        }

        .selection {
            height: 40%;
            width: 100%;
            margin-bottom: 2vh; 
        }
    </style>
</head>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="css/sidebar_admin.css" />
    <link rel="stylesheet" type="text/css" href="css/event_create.css">
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.0.0/uicons-solid-rounded/css/uicons-solid-rounded.css'>
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.0.0/uicons-bold-rounded/css/uicons-bold-rounded.css'>
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.0.0/uicons-regular-rounded/css/uicons-regular-rounded.css'>
    <title>Bienvenue</title>
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="../Images/Sonovibes_logo.png" alt="Logo Sonovibes">
        </div>
        <ul>
            <li><i class="fi fi-br-house-chimney icon" class="test"></i><a href="dashboard_admin.php">Dashboard</a></li>
            <li><i class="fi fi-br-waveform-path icon"></i><a href="event_create.php">Evenements</a></li>
            <li><i class="fi fi-br-sensor-on icon"></i><a href="capteur_sonore.php">Données capteurs</a></li>
        </ul>
        <ul>
            <div class="admin_gest">
                <div class="sidebar-title">Administration</div>
                <li><i class="fi fi-br-user icon"></i><a href="admin_faq.php">Gestion FAQ</a></li>
                <li><i class="fi fi-br-heart icon"></i><a href="admin_commentaires.php">Gestion des Commentaires</a></li>
                <li><i class="fi fi-br-sign-out-alt icon"></i><a href="admin_moderation.php">Gestion de Membres</a></li>
            </div>
        </ul>
        <ul>
            <div class="profil">
                <div class="sidebar-title">Votre compte</div>
                <li><i class="fi fi-br-user icon"></i><a href="#">Mon profil</a></li>
                <li><i class="fi fi-br-sign-out-alt icon"></i><a href="../logout.php">Déconnexion</a></li>
            </div>
        </ul>
    </div>

    <div class="content">
        <h1>Bienvenue dans ton tableau de bord <?php echo $_SESSION['prenom_participant']; ?></h1>
</body>
<body>
    <div class="form-container">
        <h2>Ajouter un Modérateur</h2>
        <form method="post">


            <label for="email">Adresse e-mail :</label>
            <input type="email" id="email" name="email" required>

            <select class="selection"  name="adminRole">
            <option value="2"> DJ </option>
            <option value="1"> Admin </option>
            <option value="0"> Rien </option>
            </select>


            <button type="submit">Ajouter Modérateur ou un DJ</button>
            <p class="note">Note : Veuillez renseigner l'email d'une personne déjà inscrite.</p>
        </form>
        <?php     
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $email_utilisateur = $_POST['email'];

        $stmt = $bdd->prepare("SELECT email_participant FROM participant WHERE email_participant = :emailToCheck");
        $stmt->bindParam(':emailToCheck', $email_utilisateur, PDO::PARAM_STR);
        $stmt->execute();
        $testo = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($testo) {
            $stmt = $bdd->prepare(
        "
        SELECT p.prenom_participant, p.nom_participant, u.roles
        FROM participant p
        JOIN utilisateur u ON p.id_participant = u.id_participant
        WHERE p.email_participant = :email_utilisateur;
        ");
        $stmt->bindParam(':email_utilisateur', $email_utilisateur, PDO::PARAM_INT);
        $stmt->execute();
        $test = $stmt->fetch(PDO::FETCH_ASSOC);
                echo($email_utilisateur);
                echo($test['roles']);
        } else { echo'existe pas';}
    }
     ?>
    </div>
</body>
</html>
