<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["submit_event"])) {
    $nom_evenement = $_POST["nom_event"];
    $date_evenement = $_POST["date_event"];
    $theme = $_POST["description_event"];
    $taille_evenement = $_POST["places_disponibles"];
    $prix_1_evenement = $_POST["Prix"];

if (isset($_FILES["image_url"]) && $_FILES["image_url"]["error"] == UPLOAD_ERR_OK) {
        // Chemin temporaire du fichier téléchargé
        $tmpFilePath = $_FILES["image_url"]["tmp_name"];
        // Lire le contenu du fichier en tant que données binaires
        $newImageData = file_get_contents($tmpFilePath);
        // Insérer les données binaires dans la base de données


     $servername = "localhost:3306";
     $username = "krcgrwhu";
     $password = "EzY2KRuspgwF9U";
     $bdd = new PDO("mysql:host=$servername;dbname=krcgrwhu_sonovibes", $username, $password);
     $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

     
     
     $stmt = $bdd->prepare("INSERT INTO evenement (nom_evenement, date_evenement, theme, taille_evenement, prix_1_evenement,image_evenement, id_utilisateur) 
     VALUES (:nom_evenement, :date_evenement, :theme, :taille_evenement, :prix_1_evenement, :image_evenement, :id_utilisateur)");

    // Remplacez les valeurs liées
    $stmt->bindParam(':nom_evenement', $nom_evenement, PDO::PARAM_STR);
    $stmt->bindParam(':date_evenement', $date_evenement, PDO::PARAM_STR);
    $stmt->bindParam(':theme', $theme, PDO::PARAM_STR);
    $stmt->bindParam(':taille_evenement', $taille_evenement, PDO::PARAM_INT);
    $stmt->bindParam(':prix_1_evenement', $prix_1_evenement, PDO::PARAM_STR);
    $stmt->bindParam(':image_evenement', $newImageData, PDO::PARAM_STR);
    $stmt->bindParam(':id_utilisateur', $_SESSION['id_utilisateur'], PDO::PARAM_INT);
    $stmt->execute();
    $result = $stmt->fetchALL(PDO::FETCH_ASSOC);
        echo "L'image a été téléversée avec succès.";
    } else {
        echo "Erreur lors du téléversement de l'image.";
    }
    


     
}


?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="css/sidebar_admin.css" />
    <link rel="stylesheet" type="text/css" href="css/event_create.css">
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.0.0/uicons-solid-rounded/css/uicons-solid-rounded.css'>
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.0.0/uicons-bold-rounded/css/uicons-bold-rounded.css'>
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.0.0/uicons-regular-rounded/css/uicons-regular-rounded.css'>
    <title>Bienvenue</title>
</head>
<body>
    <div class="sidebar">
        <div class="logo">
        <img src="../Images/Sonovibes_logo.png" alt="Logo Sonovibes">
        </div>
        <ul>
            <li><i class="fi fi-br-house-chimney icon" class="test"></i><a href="dashboard_admin.php">Dashboard</a></li>
            <li><i class="fi fi-br-waveform-path icon"></i><a href="event_create.php">Evenements</a></li>
            <li><i class="fi fi-br-sensor-on icon"></i><a href="capteur_sonore.php">Données capteurs</a></li>
        </ul>
        <ul>
            <div class="admin_gest">
                <div class="sidebar-title">Administration</div>
                <li><i class="fi fi-br-user icon"></i><a href="admin_faq.php">Gestion FAQ</a></li>
                <li><i class="fi fi-br-heart icon"></i><a href="admin_commentaires.php">Gestion des Commentaires</a></li>
                <li><i class="fi fi-br-sign-out-alt icon"></i><a href="admin_moderation.php">Gestion de Membres</a></li>
            </div>
        </ul>
        <ul>
            <div class="profil">
                <div class="sidebar-title">Votre compte</div>
                <li><i class="fi fi-br-user icon"></i><a href="#">Mon profil</a></li>
                <li><i class="fi fi-br-sign-out-alt icon"></i><a href="../logout.php">Déconnexion</a></li>
            </div>
        </ul>
    </div>

    <div class="content">
        <h1>Bienvenue dans ton tableau de bord <?php echo $_SESSION['prenom_participant']; ?></h1>

        <!-- Bouton "Nouvel événement" avec fenêtre pop-up -->
        <button id="btnNouvelEvenement">Nouvel événement</button>

        <!-- Afficher les événements existants -->
        <h2>Événements existants :</h2>
        <ul>
            
        </ul>

        <!-- Formulaire d'ajout d'événement (fenêtre pop-up) -->
        <div id="popupForm">
            <h2>Nouvel événement :</h2>
            <form method="post" enctype="multipart/form-data">
                <label for="image_url">Image de l'événement :</label>
                <input type="file" name="image_url" accept="image/*" required><br>

                <label for="nom_event">Nom de l'événement :</label>
                <input type="text" name="nom_event" required><br>

                <label for="date_event">Date de l'événement :</label>
                <input type="date" name="date_event" required><br>

                <label for="description_event">Description de l'événement :</label>
                <textarea name="description_event" required></textarea><br>

                <label for="places_disponibles">Nombre de places disponibles :</label>
                <input type="number" name="places_disponibles" required><br>

                <label for="Prix">Prix :</label>
                <input type="number" name="Prix" required><br>

                <input type="submit" name="submit_event" value="Ajouter l'événement">
                <button type="button" onclick="fermerPopup()">Fermer</button>
            </form>
        </div>

        <script>
            // Fonction pour afficher la fenêtre pop-up
            function afficherPopup() {
                document.getElementById("popupForm").style.display = "block";
            }

            // Fonction pour fermer la fenêtre pop-up
            function fermerPopup() {
                document.getElementById("popupForm").style.display = "none";
            }

            // Associer la fonction à l'événement click du bouton
            document.getElementById("btnNouvelEvenement").addEventListener("click", afficherPopup);
        </script>
    </div>
</body>
</html>
