<?php
session_start();



$servername = "localhost:3306";
$username = "krcgrwhu";
$password = "EzY2KRuspgwF9U";
$bdd = new PDO("mysql:host=$servername;dbname=krcgrwhu_sonovibes", $username, $password);
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $bdd->prepare("SELECT * FROM evenement WHERE id_utilisateur = :id_utilisateur");
    $stmt->bindParam(':id_utilisateur', $id_utilisateur, PDO::PARAM_INT); 
    $stmt->execute();
    $result = $stmt->fetchALL(PDO::FETCH_ASSOC);





?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="css/sidebar_admin.css" />
    <link rel="stylesheet" type="text/css" href="css/event_create.css">
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.0.0/uicons-solid-rounded/css/uicons-solid-rounded.css'>
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.0.0/uicons-bold-rounded/css/uicons-bold-rounded.css'>
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.0.0/uicons-regular-rounded/css/uicons-regular-rounded.css'>
    <title>Bienvenue</title>
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="../Images/Sonovibes_logo.png" alt="Logo Sonovibes">
        </div>
        <ul>
            <li><i class="fi fi-br-house-chimney icon" class="test"></i><a href="dashboard_admin.php">Dashboard</a></li>
            <li><i class="fi fi-br-waveform-path icon"></i><a href="event_create.php">Evenements</a></li>
            <li><i class="fi fi-br-sensor-on icon"></i><a href="capteur_sonore.php">Données capteurs</a></li>
        </ul>
        <ul>
            <div class="admin_gest">
                <div class="sidebar-title">Administration</div>
                <li><i class="fi fi-br-user icon"></i><a href="admin_faq.php">Gestion FAQ</a></li>
                <li><i class="fi fi-br-heart icon"></i><a href="admin_commentaires.php">Gestion des Commentaires</a></li>
                <li><i class="fi fi-br-sign-out-alt icon"></i><a href="admin_moderation.php">Gestion de Membres</a></li>
            </div>
        </ul>
        <ul>
            <div class="profil">
                <div class="sidebar-title">Votre compte</div>
                <li><i class="fi fi-br-user icon"></i><a href="#">Mon profil</a></li>
                <li><i class="fi fi-br-sign-out-alt icon"></i><a href="../logout.php">Déconnexion</a></li>
            </div>
        </ul>
    </div>

    <div class="content">
        <h1>Bienvenue dans ton tableau de bord <?php echo $_SESSION['prenom_participant']; ?></h1>
</body>
</html>
