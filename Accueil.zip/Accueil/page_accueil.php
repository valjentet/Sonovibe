<?php session_start(); ?>


<!DOCTYPE html>

<html>
  <head>
    <meta charset="utf-8" />
    <link rel="stylesheet" type="text/css" href="page_accueil.css" />
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.0.0/uicons-brands/css/uicons-brands.css'>
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.0.0/uicons-regular-rounded/css/uicons-regular-rounded.css'>
    <title>page d'accueil</title>
  </head>
  <body>
    <div class="total">
    <nav>
        <div name="logo" id="logonav">
          <a href="../Accueil/page_accueil.php"><img name="logo_sono" src="../Images/Sonovibes_logo.png" width="120" height="80"></a>
        </div>
        <div id="middle-section">
            <?php 
            if ($_SESSION['connecte'] == 1) {
                echo '
                <a href="../Accueil/page_accueil.php" class="a"><b><span class="atextenav">Accueil</span></b></a>
                <a href="../Evenement/page_evenement.php" class="a"><span class="atextenav">Événements</span></a>
                <a href="../Mon_compte/page_forum.php" class="a"><span class="atextenav">Forum</span></a>
                <a href="../Mon_compte/page_mon_compte.php" class="a"><span class="atextenav">Mes événements</span></a>
                <a href="../DJ/page_dj.php" class="a"><span class="atextenav">page DJ</span></a>';
            } else {echo '
                <a href="../Accueil/page_accueil.php" class="a"><b> <span class="atextenav">Accueil</span></b></a>
                <a href="../Evenement/page_evenement.php" class="a"><span class="atextenav">Événements</span></a>
                <a href="../Mon_compte/page_forum.php" class="a"><span class="atextenav">Forum</span></a>
                <a href="../pas_connecte.php" class="a"><span class="atextenav">Mes événements</span></a>';
            }

            if ($_SESSION['roles'] == 1) {echo '    <a href="../Admin/dashboard_admin.php" class="a"><span class="atextenav">Administration</span></a>
            ';}
            ?>                
            </div>

            <div id="right-section">
                <?php 
            if ($_SESSION['connecte'] == 1) { 
                
                echo '<a href="../Mon_compte/page_mon_compte_profil.php" class="b"><button class="binscription"> Bienvenue   ' . $_SESSION['prenom_participant'] . ' !</button></a>';
            } 
            else {
                echo '<button class="bconnexion"><a href="../Connexion/page_connexion.html" class="a">Connexion</a></button>
                <button class="binscription"><a href="../Connexion/page_inscription.html" class="b">Inscription</a></button>'; 
                
            }
            
            ?>
        </div>
    </nav>


      <div class="header_total">
        <div class="header">
          <div class="column">
            <img src="../Images/photo_yasmine/header_accueil.png" class="img_header">  
          </div>
          <div class="column-2">
            <div class="text_droite">
              <div class="titre">
                <span>Bienvenue sur</span>
                <span>SONOVIBE</span>
              </div>
              <div class="text_desc">
                Votre outil de réservation, 100% en ligne
                <a href="../Connexion/page_connexion.html"><button class="btn_connec_header"> Connectez-vous</button></a>
              </div>
            </div>
          </div>
        </div>
      </div>
      

      <div class="event">
        <div class="div-20">Evènements à venir</div>
        <div class="div-21">
          <div class="div-22">Vous souhaitez voir plus d’évènements ?</div>
          <a class="redir_event" href="#">Accedez a tous les évènements !</a>
        </div>
        <div class="div-24">
          <div class="div-25">
            <div class="column-3">
              <div class="div-26">
                <div class="bg_event">
                  <div class="icon_event">
                    <i class="fi fi-rr-document"></i>
                  </div>
                </div>
                <div class="div-28">
                  <div class="div-29">Event 1</div>
                  <div class="div-30">
                  </div>
                </div>
              </div>
            </div>
            <div class="column-4">
              <div class="div-31">
                <div class="bg_event">
                  <div class="icon_event">
                    <i class="fi fi-rr-document"></i>
                  </div>
                </div>
                <div class="div-33">
                  <div class="div-34">Event 1</div>
                  <div class="div-35">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="div-36">
          <div class="div-37">
            <div class="column-5">
              <div class="div-38">
                <div class="bg_event">
                  <div class="icon_event">
                    <i class="fi fi-rr-document"></i>
                  </div>
                </div>
                <div class="div-40">
                  <div class="div-41">Event 1</div>
                  <div class="div-42">
                  </div>
                </div>
              </div>
            </div>
            <div class="column-6">
              <div class="div-43">
                <div class="bg_event">
                  <div class="icon_event">
                    <i class="fi fi-rr-document"></i>
                  </div>
                </div>
                <div class="div-45">
                  <div class="div-46">Event 1</div>
                  <div class="div-47">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <img
        loading="lazy"
        src="https://cdn.builder.io/api/v1/image/assets/TEMP/a53e3539a878027a138b6f940d654807e6ea5a1e2376840c9a1f483042eb533f?"
        class="img-6"
      />
      <div class="div-48">
        <div class="div-49">SONOVIBE</div>
        <div class="div-50">Vos avis sur notre produit !</div>
        <div class="div-51">
          <div class="div-52">
            <div class="column-7">
              <div class="card_gene">
                <div class="top_card">
                  <img
                    src="../Images/photo_yasmine/user.png"
                    class="user_icon"
                  />
                  <div class="div-55">
                    <div class="div-56">USER</div>
                    <div class="div-57">Date 25/02/2023</div>
                  </div>
                </div>
                <div class="div-58">               
                </div>
              </div>
            </div>
            <div class="column-8">
              <div class="card_gene">
                <div class="top_card">
                  <img
                  src="../Images/photo_yasmine/user.png"
                  class="user_icon"
                  />
                  <div class="div-61">
                    <div class="div-62">USER</div>
                    <div class="div-63">Date 25/02/2023</div>
                  </div>
                </div>
                <div class="div-64">               
                </div>
              </div>
            </div>
            <div class="column-9">
              <div class="card_gene">
                <div class="top_card">
                  <img
                  src="../Images/photo_yasmine/user.png"
                  class="user_icon"
                  />
                  <div class="div-67">
                    <div class="div-68">USER</div>
                    <div class="div-69">Date 25/02/2023</div>
                  </div>
                </div>
                <div class="div-70">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="div-71">
        <div class="div-72">
          <div class="div-73">
            <div class="column-10">
              <div class="div-74">
                <div class="div-75">
                  Nous contacter ?
                  <br />
                  Envoyez nous un message
                </div>
                <div class="div-76">Que voulez-vous nous dire ?</div>
              </div>
            </div>
            <div class="column-11">
              <div class="send_mail">
                <input type="text" placeholder="Votre message ici ..." class="input_mail"/>
                <div class="icon_mail">
                  <i class="fi fi-rr-paper-plane"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="footer_total">
          <div class="foot">
            <div class="column-12">
              <div class="log_foot">
                <img src="../Images/Sonovibes_logo.png" class="logo_sono_foot"/>
                <div class="icon_gene">
                  <div class="icon_facebook">
                    <i class="fi fi-brands-facebook"></i>
                  </div>
                  <div class="icon_twitter">
                    <i class="fi fi-brands-twitter"></i>
                  </div>
                  <div class="icon_insta">
                    <i class="fi fi-brands-instagram"></i>
                  </div>
                </div>
                <div class="copyright">Copyright © 2024 sonovibes</div>
              </div>
            </div>
            <div class="full_link">
              <div class="div-84">
                  <div class="div-86">
                    <div class="column_link">
                        <div class="grand_link">Navigation</div>
                        <a href="#" class="link_footer">Accueil</a>
                        <a href="../Evenement/page_evenement.php" class="link_footer">Évènements</a>
                        <a href="#" class="link_footer">Notre Produit</a>
                        <a href="#" class="link_footer">Contact</a>
                    </div>
                    <div class="column_link">
                        <div class="grand_link">À propos</div>
                        <a href="mentions_legales.html" class="link_footer">Mention légales</a>
                        <a href="#" class="link_footer">Acheter</a>
                        <a href="#" class="link_footer">Avis</a>
                        <a href="#" class="link_footer">FAQ</a>
                    </div>
                    <div class="column_link">
                        <div class="grand_link">Villes</div>
                        <a href="#" class="link_footer">Paris</a>
                        <a href="#" class="link_footer">Issy-les-moulinaux</a>
                    </div>
                    <div class="column_link">
                        <div class="grand_link">Equipe</div>
                        <div class="link_footer">Yasmine</div>
                        <div class="link_footer">Erwan</div>
                        <div class="link_footer">Sasha</div>
                        <div class="link_footer">Arnaud</div>
                        <div class="link_footer">Eric</div>
                        <div class="link_footer">Valentin</div>
                      </div>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
  