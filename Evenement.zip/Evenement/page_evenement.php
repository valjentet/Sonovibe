<?php
session_start();
$servername = "localhost:3306";
$username = "krcgrwhu";
$password="EzY2KRuspgwF9U"; 
try { //méthode try catch
    $bdd = new PDO("mysql:host=$servername;dbname=krcgrwhu_sonovibes", $username, $password);
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    
        //on cherche tous les évènement à venir
        $dateActuelle = date("Y-m-d");
        $stmt = $bdd->prepare("SELECT * FROM evenement WHERE date_evenement >= :date_actuelle");
        $stmt->bindParam(':date_actuelle', $dateActuelle, PDO::PARAM_STR);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

} 
catch (PDOException $e) {

    echo "Erreur : " . $e->getMessage();
}
?>





<html>
<link rel="stylesheet" href="page_evenement.css">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page évènement</title>
</head>
<body>
<nav>
        <div name="logo" id="logonav">
          <a href="../Accueil/page_accueil.php"><img name="logo_sono" src="../Images/Sonovibes_logo.png" width="120" height="80"></a>
        </div>
        <div id="middle-section">
            <?php 
            if ($_SESSION['connecte'] == 1) {
                echo '
                <a href="../Accueil/page_accueil.php" class="a"> <span class="atextenav">Accueil</span></a>
                <a href="../Evenement/page_evenement.php" class="a"><b><span class="atextenav">Événements</span></b></a>
                <a href="../Mon_compte/page_forum.php" class="a"><span class="atextenav">Forum</span></a>
                <a href="../Mon_compte/page_mon_compte.php" class="a"><span class="atextenav">Mes événements</span></a>';
            } else {echo '
                <a href="../Accueil/page_accueil.php" class="a"> <span class="atextenav">Accueil</span></a>
                <a href="../Evenement/page_evenement.php" class="a"><b><span class="atextenav">Événements</span></b></a>
                <a href="../Mon_compte/page_forum.php" class="a"><span class="atextenav">Forum</span></a>
                <a href="../pas_connecte.php" class="a"><span class="atextenav">Mes événements</span></a>';
            }

            if ($_SESSION['roles'] == 1) {echo '    <a href="../Admin/dashboard_admin.php" class="a"><span class="atextenav">Administration</span></a> ';}
            ?>                
            </div>

            <div id="right-section">
                <?php 
            if ($_SESSION['connecte'] == 1) { 
                
                echo '<a href="../Mon_compte/page_mon_compte_profil.php" class="b"><button class="binscription"> Bienvenue   ' . $_SESSION['prenom_participant'] . ' !</button></a>';
            } 
            else {
                echo '<button class="bconnexion"><a href="../Connexion/page_connexion.html" class="a">Connexion</a></button>
                <button class="binscription"><a href="../Connexion/page_inscription.html" class="b">Inscription</a></button>'; 
                
            }
            
            ?>
        </div>
    </nav>










    
    <div class="block_event_principal">
         <ul class="liste_evenement">
        <li class="block_event_haut">  
            <div class="gros_block_event">
                <img class=image_de_gauche src="../Images/photo_val/soiree.jpg" alt="photo" >
                 
                
                <div class="texte_de_droite">
                    <div class="petit_texte_evenement_haut"> <center><b>Le meilleur des <br>évènements <br> <span class="mot_sonovibes_en_bleue">Sonovibes</span> à <br> venir</b></center></div>
                    <div class="pave_evenement_haut">
Bienvenue sur la plateforme des soirées  sonovibes ! Découvrez  des expériences nocturnes uniques , avec des DJs renommés et des lieux prestigieux.   Réservez vos billets en ligne et   plongez dans l'excitation. Ne  manquez  pas l'événement  de l'année. Rejoignez la fête dès maintenant.
Bienvenue sur la plateforme des soirées  sonovibes ! Découvrez  des expériences nocturnes uniques , avec des DJs renommés et des lieux prestigieux.   Réservez vos billets en ligne et   plongez dans l'excitation. Ne  manquez  pas l'événement  de l'année. Rejoignez la fête dès maintenant.</div>
                </div>
                
            
            
            </div>  
                
        </li> 
        <?php


foreach ($result as $evenement) {
    // Récupérer les données binaires de l'image pour chaque événement
    $id_evenement = $evenement['id_evenement'];

    echo '
     <div class="blockevent">
        <div class="textblockevent">
            <p class="texteevent"> <span class="date_evenement"> Le '.$evenement['date_evenement'].' :  </span>   <br>
             ' .  $evenement['theme'] .'</p>
        </div>
        <div class="imagblockevent">
            <span class="nom_evenement"  > '.$evenement['nom_evenement'].'</span>
            <img src="data:image/png;base64,' .base64_encode($evenement['image_evenement']). '" alt="Votre Image" class="imageevent">
            <span  class="texteevent"  class="taille_evenement"> Il reste encore '.$evenement['taille_evenement'].' places !! </span>
            <br>'; 
            if ($_SESSION['connecte']==1) {echo '<a class="texteevent" href="../Reservation/page_reservation.php?id_evenement='.$id_evenement.'"> Reserver dès maintenant</a>
        </div>
    </div> '; } else {echo '<a class="texteevent" href="../pas_connecte.php?id_evenement='.$id_evenement.'"> Reserver dès maintenant</a>
        </div>
    </div> ';}
}

?>

        


    </ul>

    </div>
    

</body>
</html> ';