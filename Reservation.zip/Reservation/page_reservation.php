<?php
session_start();

// Informations de connexion à la base de données
$servername = "localhost:3306";
$username = "krcgrwhu";
$password="EzY2KRuspgwF9U";

// Récupération de l'ID de l'événement depuis la requête GET
$_SESSION['evenement_choisi'] = $_GET['id_evenement'];
$id_evenement = $_SESSION['evenement_choisi'];

try {
    // Connexion à la base de données
    $bdd = new PDO("mysql:host=$servername;dbname=krcgrwhu_sonovibes", $username, $password);
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Requête pour récupérer les détails de l'événement sélectionné
    $stmt = $bdd->prepare("SELECT * FROM evenement WHERE id_evenement = :id_evenement");
    $stmt->bindParam(':id_evenement', $id_evenement, PDO::PARAM_INT); 
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    // Si des résultats sont trouvés, stocker les informations de l'événement dans la session
    if ($result) {
        $_SESSION['nom_evenement'] = $result['nom_evenement'];
        $_SESSION['date_evenement'] = $result['date_evenement'];
        $_SESSION['heure_evenement'] = $result['heure_evenement'];
        $_SESSION['theme'] = $result['theme'];
        $_SESSION['taille_evenement'] = $result['taille_evenement'];
        $_SESSION['adresse_evenement'] = $result['adresse_evenement'];
    } else {
        // Si aucun résultat n'est trouvé, afficher un message d'erreur
        echo "Aucun événement trouvé avec l'ID $id_evenement";
    }

    // Requête pour obtenir le prix unitaire en fonction de la date

// ancien code pour le triple prix
    //SELECT 
    //CASE 
      //  WHEN prix_1_fin_date >= NOW() THEN prix_1_evenement
       // WHEN prix_2_fin_date >= NOW() THEN prix_2_evenement
       // WHEN prix_3_fin_date >= NOW() THEN prix_3_evenement
        //ELSE 10  -- Défaut si aucune date d'expiration n'est trouvée
    //END AS prix_unitaire
    //FROM evenement WHERE id_evenement = :id_evenement



    
    $stmtPrixUnitaire = $bdd->prepare("SELECT 
        prix_1_evenement
        FROM evenement WHERE id_evenement = :id_evenement");
    $stmtPrixUnitaire->bindParam(':id_evenement', $id_evenement, PDO::PARAM_INT);
    $stmtPrixUnitaire->execute();
    $prixUnitaireResult = $stmtPrixUnitaire->fetch(PDO::FETCH_ASSOC);

    // Si des résultats sont trouvés, stocker le prix unitaire
    if ($prixUnitaireResult) {
        $prixUnitaire = $prixUnitaireResult['prix_1_evenement'];
    } else {
        // Défaut si aucun prix n'est trouvé pour la date actuelle
        $prixUnitaire = 10;
    }

} catch (PDOException $e) {
    // Gestion des erreurs PDO
    echo "Erreur : " . $e->getMessage();
}

// Requête pour obtenir l'image de l'événement depuis la base de données
$stmt = $bdd->prepare("SELECT image_evenement FROM evenement WHERE id_evenement = $id_evenement");
$stmt->execute();
$imageData = $stmt->fetch(PDO::FETCH_ASSOC)['image_evenement'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="Réservation.css">
    <title>Page réservation</title>
</head>
<body>
    <!-- Barre de navigation -->
    <nav>
        <div name="logo" id="logonav">
          <a href="../Accueil/page_accueil.php"><img name="logo_sono" src="../Images/Sonovibes_logo.png" width="120" height="80"></a>
        </div>
        <div id="middle-section">
            <?php 
            if ($_SESSION['connecte'] == 1) {
                echo '
                <a href="../Accueil/page_accueil.php" class="a"> <span class="atextenav">Accueil</span></a>
                <a href="../Evenement/page_evenement.php" class="a"><span class="atextenav">Événements</span></a>
                <a href="../Mon_compte/page_forum.php" class="a"><span class="atextenav">Forum</span></a>
                <a href="../Mon_compte/page_mon_compte.php" class="a"><span class="atextenav">Mes événements</span></a>';
            } else {echo '
                <a href="../Accueil/page_accueil.php" class="a"> <span class="atextenav">Accueil</span></a>
                <a href="../Evenement/page_evenement.php" class="a"><span class="atextenav">Événements</span></a>
                <a href="../Mon_compte/page_forum.php" class="a"><span class="atextenav">Forum</span></a>
                <a href="../pas_connecte.php" class="a"><span class="atextenav">Mes événements</span></a>';
            }

            if ($_SESSION['roles'] == 1) {echo '    <a href="../Admin/dashboard_admin.php" class="a"><span class="atextenav">Administration</span></a> ';}
            ?>                
            </div>

            <div id="right-section">
                <?php 
            if ($_SESSION['connecte'] == 1) { 
                
                echo '<a href="../Mon_compte/page_mon_compte_profil.php" class="b"><button class="binscription"> Bienvenue   ' . $_SESSION['prenom_participant'] . ' !</button></a>';
            } 
            else {
                echo '<button class="bconnexion"><a href="../Connexion/page_connexion.html" class="a">Connexion</a></button>
                <button class="binscription"><a href="../Connexion/page_inscription.html" class="b">Inscription</a></button>'; 
                
            }
            
            ?>
        </div>
    </nav>

    <!-- Formulaire de réservation -->
    <form method="POST" action="page_de_paiement.php" id="reservationform">
        <!-- Image de l'événement récupérée depuis la base de données -->
        <?php echo '<img src="data:image/png;base64,' . base64_encode($imageData) . '" alt="Image soirée" class="imageevent" width=600>'?> 
        <!-- Informations sur l'événement -->
        <h1><?php echo $_SESSION['nom_evenement']; ?></h1>
        <p>Adresse: <?php echo $_SESSION['adresse_evenement']; ?></p>
        <p>Date: <?php echo $_SESSION['date_evenement']; ?></p>
        <p>Heure: <?php echo $_SESSION['heure_evenement']; ?></p>
        <!-- Description de l'événement -->
        <h2>Description de l'événement</h2>
        <strong><textarea name="descriptionevent" id="descriptionevent" rows="10" cols="100" readonly><?php echo $_SESSION['theme']; ?></textarea>
        <br>
        <!-- Indicateur de prix et champ de saisie du nombre d'entrées -->
        <div id="indicateurPrix">
            <label for="nombreEntrees">Nombre d'entrées :</label>
            <input type="number" placeholder="0" id="nombreEntrees" name="nombreEntrees" onchange="updateTotal()" max="<?php echo $_SESSION['taille_evenement']; ?>" required>
            <!-- Affichage du prix de l'entrée et du total à payer -->
            <p>Prix de l'entrée : <?php echo $prixUnitaire; ?> €</p>
            <p>Total à payer : <span name="prixTotal" id="prixTotal">0.00 €</span></p>
        </div>
        <br>
        <!-- Bouton de réservation -->
        <button class="breserver" name="breserver" type="submit" >Réserver</button>
    </form>

    <!-- Script JavaScript pour mettre à jour le prix total -->
    <script>
        // Fonction pour mettre à jour le prix total
        function updateTotal() {
            // Récupérer le nombre d'entrées sélectionné
            var nombreEntrees = document.getElementById("nombreEntrees").value;

            // Vérifier que le nombre d'entrées est valide
            if (nombreEntrees < 0) {
                alert("Le nombre d'entrées ne peut pas être inférieur à 0.");
                document.getElementById("nombreEntrees").value = 0;
                nombreEntrees = 0;
            }

            // Vérifier que le nombre d'entrées ne dépasse pas la taille de l'événement
            var tailleEvenement = <?php echo $_SESSION['taille_evenement']; ?>;
            if (nombreEntrees > tailleEvenement) {
                alert("Le nombre d'entrées ne peut pas dépasser la taille de l'événement.");
                document.getElementById("nombreEntrees").value = tailleEvenement;
                nombreEntrees = tailleEvenement;
            }

            // Prix unitaire basé sur la date actuelle
            var prixUnitaire = <?php echo json_encode($prixUnitaire); ?>;

            // Calculer le prix total
            var prixTotal = nombreEntrees * prixUnitaire;

            // Mettre à jour l'affichage du prix total
            document.getElementById("prixTotal").textContent = prixTotal.toFixed(2) + " €";
            localStorage.setItem('prixTotal', prixTotal);
            // Stocker le prixTotal dans la session
            sessionStorage.setItem('prixTotal', prixTotal);
        }

        // Ajouter un écouteur d'événements pour le formulaire
        document.getElementById('reservationform').addEventListener('submit', function(event) {
            // Mettre à jour le prix total
            updateTotal();
        });      
    </script> 
</body>
</html>
