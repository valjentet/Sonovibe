<?php 
session_start();

// Récupérer la date et l'heure actuelles pour le paiement
$date_paiement = date("Y-m-d");
$heure_paiement = date("H:i:s");

// Récupérer les autres données du formulaire
// Récupérer le prixTotal de la session
$prix_total = isset($_SESSION['prixTotal']) ? $_SESSION['prixTotal'] : 0;
$heure_entree = $_SESSION['heure_evenement']; // Assurez-vous que cette variable provient du formulaire
$date_entree = $_SESSION['date_evenement']; // Assurez-vous que cette variable provient du formulaire
$numero_de_carte = $_POST['card_number'];
$date_expiration_carte = $_POST['expiry_date'];
$nom_titulaire_carte = $_POST['name'];

// Récupérer l'id_evenement et l'id_participant de la session
$id_evenement = $_SESSION['evenement_choisi'];
$id_participant = $_SESSION['id_participant'];

// Connexion à la base de données
$servername = "localhost:3306";
$username = "krcgrwhu";
$password="EzY2KRuspgwF9U";
$database = "krcgrwhu_sonovibes";

try {
    $bdd = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Préparation de la requête d'insertion dans la table ticket
    $stmt = $bdd->prepare("INSERT INTO ticket (num_ticket, date_paiement, heure_paiement, prix_ticket, heure_entree, date_entree, numero_de_carte, id_evenement, id_participant, date_expiration_carte, nom_titulaire_carte) VALUES (:num_ticket, :date_paiement, :heure_paiement, :prix_ticket, :heure_entree, :date_entree, :numero_de_carte, :id_evenement, :id_participant, :date_expiration_carte, :nom_titulaire_carte)");

    // Génération d'un numéro de ticket aléatoire 
    $num_ticket = rand(100000, 999999);

    // Liaison des paramètres
    $stmt->bindParam(':num_ticket', $num_ticket, PDO::PARAM_INT);
    $stmt->bindParam(':date_paiement', $date_paiement, PDO::PARAM_STR);
    $stmt->bindParam(':heure_paiement', $heure_paiement, PDO::PARAM_STR);
    $stmt->bindParam(':prix_ticket', $prix_total, PDO::PARAM_INT);
    $stmt->bindParam(':heure_entree', $heure_entree, PDO::PARAM_STR);
    $stmt->bindParam(':date_entree', $date_entree, PDO::PARAM_STR);
    $stmt->bindParam(':numero_de_carte', $numero_de_carte, PDO::PARAM_STR);
    $stmt->bindParam(':date_expiration_carte', $date_expiration_carte, PDO::PARAM_STR);
    $stmt->bindParam(':nom_titulaire_carte', $nom_titulaire_carte, PDO::PARAM_STR);
    $stmt->bindParam(':id_evenement', $id_evenement, PDO::PARAM_INT);
    $stmt->bindParam(':id_participant', $id_participant, PDO::PARAM_INT);

    // Exécution de la requête
    $stmt->execute();

    echo "Enregistrement dans la table ticket réussi.";

} catch (PDOException $e) {
    echo "Erreur : " . $e->getMessage();
}

// Une fois la connexion réussie, redirigez vers la page ticket
header("Location: Page_ticket.php");
exit; // Appeler exit après header pour éviter l'exécution continue du script
?>
