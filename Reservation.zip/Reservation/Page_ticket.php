<?php
session_start();

// Connexion à la base de données
$servername = "localhost:3306";
$username = "krcgrwhu";
$password="EzY2KRuspgwF9U";
$database = "krcgrwhu_sonovibes";

try {
    $bdd = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Requête pour récupérer les tickets liés à un participant, triés par date d'événement
    $stmt = $bdd->prepare("SELECT t.*, e.date_evenement, e.image_evenement FROM ticket t JOIN evenement e ON t.id_evenement = e.id_evenement 
    WHERE t.id_participant = :id_participant ORDER BY `e`.`date_evenement` ASC");
    $stmt->bindParam(':id_participant', $_SESSION['id_participant'], PDO::PARAM_INT); 
    $stmt->execute();
    $tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    echo "Erreur : " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="Ticket.css">
    <title>Page Ticket</title>
</head>
<body>




<nav>
        <div name="logo" id="logonav">
          <a href="../Accueil/page_accueil.php"><img name="logo_sono" src="../Images/Sonovibes_logo.png" width="120" height="80"></a>
        </div>
        <div id="middle-section">
            <?php 
            if ($_SESSION['connecte'] == 1) {
                echo '
                <a href="../Accueil/page_accueil.php" class="a"> <span class="atextenav">Accueil</span></a>
                <a href="../Evenement/page_evenement.php" class="a"><span class="atextenav">Événements</span></a>
                <a href="../Mon_compte/page_forum.php" class="a"><span class="atextenav">Forum</span></a>
                <a href="../Mon_compte/page_mon_compte.php" class="a"><span class="atextenav">Mes événements</span></a>';
            } else {echo '
                <a href="../Accueil/page_accueil.php" class="a"> <span class="atextenav">Accueil</span></a>
                <a href="../Evenement/page_evenement.php" class="a"><span class="atextenav">Événements</span></a>
                <a href="../Mon_compte/page_forum.php" class="a"><span class="atextenav">Forum</span></a>
                <a href="../pas_connecte.php" class="a"><span class="atextenav">Mes événements</span></a>';
            }

            if ($_SESSION['roles'] == 1) {echo '    <a href="../Admin/dashboard_admin.php" class="a"><span class="atextenav">Administration</span></a> ';}
            ?>                
            </div>

            <div id="right-section">
                <?php 
            if ($_SESSION['connecte'] == 1) { 
                
                echo '<a href="../Mon_compte/page_mon_compte_profil.php" class="b"><button class="binscription"> Bienvenue   ' . $_SESSION['prenom_participant'] . ' !</button></a>';
            } 
            else {
                echo '<button class="bconnexion"><a href="../Connexion/page_connexion.html" class="a">Connexion</a></button>
                <button class="binscription"><a href="../Connexion/page_inscription.html" class="b">Inscription</a></button>'; 
                
            }
            
            ?>
        </div>
    </nav>



<div class="fbox">
<h1>Liste des Tickets</h1>

<?php foreach ($tickets as $ticket): ?>
    <div class="ticket">
        <!-- Image de l'événement -->
        <?php echo '<img src="data:image/png;base64,' . base64_encode($ticket['image_evenement']) . '" alt="Image soirée" class="imageevent" width=600>' ?>

        <!-- Détails du ticket -->
        <p><strong>Numéro de Ticket:</strong> <?= $ticket['num_ticket'] ?></p>
        <p><strong>Date de Paiement:</strong> <?= $ticket['date_paiement'] ?></p>
        <p><strong>Heure de Paiement:</strong> <?= $ticket['heure_paiement'] ?></p>
        <p><strong>Heure d'Entrée:</strong> <?= $ticket['heure_entree'] ?></p>
        <p><strong>Date d'Entrée:</strong> <?= $ticket['date_entree'] ?></p>
    </div>
<?php endforeach; ?>
</div>

</body>
</html>
