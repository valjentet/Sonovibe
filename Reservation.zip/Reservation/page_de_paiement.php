<!DOCTYPE html> 
<html>
    <header>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="Paiement.css">
        <title>Page de paiement</title>
    </header>
    <body>
        <!-- Conteneur principal de la page -->
        <div class="container">
            <!-- Titre de la page -->
            <h1>Page de paiement</h1>
            <!-- Formulaire de paiement avec action pointant vers "traitement_paiement.php" et méthode POST -->
            <form action="Traitement_paiement.php" method="POST">
                <!-- Champ de saisie pour le numéro de carte -->
                <div class="form-group">
                    <label for="card_number">Numéro de carte :</label>
                    <input type="text" id="card_number" name="card_number" placeholder="1234 5678 9012 3456" required>
                </div>
                <!-- Champ de saisie pour la date d'expiration -->
                <div class="form-group">
                    <label for="expiry_date">Date d'expiration :</label>
                    <input type="date" id="expiry_date" name="expiry_date" placeholder="MM/AA" required>
                </div>
                <!-- Champ de saisie pour le code de sécurité CVV -->
                <div class="form-group">
                    <label for="cvv">CVV :</label>
                    <input type="text" id="cvv" name="cvv" placeholder="123" required>
                </div>
                <!-- Champ de saisie pour le nom du titulaire de la carte -->
                <div class="form-group">
                    <label for="name">Nom du titulaire de la carte :</label>
                    <input type="text" id="name" name="name" placeholder="John Doe" required>
                </div>
                <!-- Élément paragraphe pour afficher le montant total -->
                <div class="form-group">
                    <p id="totalElement">Total: </p>
                </div>
                <!-- Bouton de soumission du formulaire -->
                <button type="submit" class="btn">Payer</button>
            </form>
        </div>

        <script>
            // Récupérer le prix total du stockage local
            var total = localStorage.getItem('prixTotal');

            // Sélection de l'élément où l'on veut afficher le montant
            var totalElement = document.getElementById('totalElement');

            // Afficher le montant dans l'élément sélectionné
            totalElement.textContent += total + " €";
        </script>
    </body>
</html>
