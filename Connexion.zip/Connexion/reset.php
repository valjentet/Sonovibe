<?php


$servername="localhost:3306";

$username="krcgrwhu";
$password="EzY2KRuspgwF9U";
// Connexion par PDO à la BDD
try{
    $bdd= new PDO("mysql:host=$servername;dbname=krcgrwhu_sonovibes",$username,$password);
    $bdd->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e){
    echo "Erreur : ".$e->getMessage();
}
  
    use PHPMailer\PHPMailer\PHPMailer; 
    use PHPMailer\PHPMailer\SMTP; 
    use PHPMailer\PHPMailer\Exception; 
    
    
    require 'PHPMailer/Exception.php'; 
    require 'PHPMailer/PHPMailer.php'; 
    require 'PHPMailer/SMTP.php'; 

    if(isset($_POST['envoie_mail'])){
        $destinataire=$_POST['mail_recepteur'];
        $_SESSION['email_participant'] = $_POST['mail_recepteur'];

        $stmt = $bdd->prepare("SELECT email_participant FROM participant WHERE email_participant = :destinataire");
        $stmt->bindParam(':destinataire', $destinataire, PDO::PARAM_STR);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
    // Vérifiez si l'email existe 
        if ($result) {
            $sqlUpdate = "UPDATE email_ephemere SET email_ephemere = :nouvel_email";
        $stmtUpdate = $bdd->prepare($sqlUpdate);
        $stmtUpdate->bindParam(':nouvel_email', $destinataire, PDO::PARAM_STR);
        $stmtUpdate->execute();
        

            function email_inscription($destinataire){
                $sujet= "[Sonovibes] Reinitialisation de votre mot de passe";
                $message = file_get_contents('message.php');
                $mailSent = send_mail_PHPMailer($destinataire,$sujet,$message);
                
                    
            }
            function send_mail_PHPMailer($destinataire,$sujet,$message){        

                $mail = new PHPMailer(true); 
                try {
                    
                    //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                           
                    $mail->isSMTP();                                                 
                    $mail->Host = 'smtp.gmail.com';                                 
                    $mail->SMTPAuth   = true;                                      
                    $mail->Username = 'noreply.sonovibes@gmail.com';         //SMTP username
                    $mail->Password = 'xvizfijfvzhhhwgn ';                 //SMTP password
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            
                    $mail->Port = 587;                                         
                    $mail->SMTPSecure = "tls";
                    //Recipients
                    $mail->setFrom('noreply.sonovibes@gmail.com', 'Sonovibes');
                    $mail->addAddress($destinataire);    

                    //Content
                    $mail->isHTML(true);                                  
                    $mail->Subject = $sujet;
                    $mail->Body    = $message;
                    $mail->AltBody = 'En texte pour les clients ayant pas HTML';
                    
                    $mail->send();
                    echo '<br>Mail envoyé';
                    return true;
                } catch (Exception $e) {
                    echo "<br>Le mail n'a pas été envoyé. Mailer Error: {$mail->ErrorInfo}";
                    return false;
                }
            }
             email_inscription($destinataire);
        }
        else{
            echo '<br><script> alert("Vous avez pas de compte avec cette adresse mail");</script>'; 
            ob_start();
            // Redirige vers la page précédente après 2 secondes (2000 millisecondes)
            echo '<script type="text/javascript">setTimeout(function(){ history.go(-1); }, 1000);</script>';

            ob_end_flush();
            exit(); 
        }
    }   
?>