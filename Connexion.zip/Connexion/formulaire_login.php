<?php // Auteur : Erwan Gingembre
session_start();
$servername="localhost:3306";
$username="krcgrwhu";
$password="EzY2KRuspgwF9U";

$_SESSION['connecte'] = 0; // Ouverture de la session
// On utilise PDO
try{
    $bdd= new PDO("mysql:host=$servername;dbname=krcgrwhu_sonovibes",$username,$password);
    $bdd->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e){
    echo "Erreur : ".$e->getMessage();
}
// On récupère les données du formulaire via POST
if($_SERVER["REQUEST_METHOD"]== "POST"){
    $email_participant=securite($_POST['mail']);
    $mot_de_passe_participant=securite($_POST['Password']);
    if($email_participant != "" && $mot_de_passe_participant != ""){ // si adresse mail non vide et mot de passe non vide on prépare et exécute la requête
        $req = $bdd->prepare("SELECT * FROM participant WHERE email_participant = :email_participant");
        $req->execute(array('email_participant' => $email_participant));
        $verif = $req->fetch(PDO::FETCH_ASSOC);

        if ($verif && password_verify($mot_de_passe_participant, $verif['mot_de_passe_participant'])) { // Si le mot de passe est bien celui du participant
            
            
            
            
            $_SESSION['id_participant'] =               $verif['id_participant'];
            $_SESSION['prenom_participant'] =           $verif['prenom_participant'];
            $_SESSION['nom_participant'] =              $verif['nom_participant'];
            $_SESSION['email_participant'] =            $verif['email_participant'];
            $_SESSION['numero_de_tel_participant'] =    $verif['numero_de_tel_participant'];
            $_SESSION['mot_de_passe_participant'] =     $verif['mot_de_passe_participant'];
            $_SESSION['confirmation_mdp_participant'] = $verif['confirmation_mdp_participant'];
            $_SESSION['connecte'] = 1;
            
            $req = $bdd->prepare("SELECT * FROM utilisateur WHERE email_utilisateur = :email_utilisateur");
            $req->execute(array('email_utilisateur' => $_SESSION['email_participant']));  
            $result = $req->fetch(PDO::FETCH_ASSOC); // On execute la requête préparée
            if ($result) {
            $_SESSION['roles'] = $result['roles'];
            $_SESSION['id_utilisateur'] = $result['id_utilisateur'];

            }            
            //Redirection côté serveur vers la page client
            header("Locaction: ../Evenement/page_evenement.php" ); 
            echo json_encode(array("success" => true));
            // On envoie la réponse au js par un code json
            exit();
        } else {
            echo json_encode(array("success" => false));
        }
    }
}
function securite($données) {
    $données = trim($données);
    $données = stripslashes($données);
    $données = htmlspecialchars($données);
    return $données;
}
?>