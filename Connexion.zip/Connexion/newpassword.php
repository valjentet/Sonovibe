<?php

$servername = "localhost:3306";
$username = "krcgrwhu";
$password = "EzY2KRuspgwF9U";

try {
    // Connexion par PDO à la BDD
    $bdd = new PDO("mysql:host=$servername;dbname=krcgrwhu_sonovibes", $username, $password);
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Récupération de l'e-mail depuis la table email_ephemere
    $sql = "SELECT email_ephemere FROM email_ephemere";
    $stmt = $bdd->prepare($sql);
    $stmt->execute();
    $destinataire = $stmt->fetchColumn();

    if (isset($_POST['confirmation'])) {
        $mot_de_passe = securite($_POST['new_mdp']);
        $conf_mdp = securite($_POST['conf_new_mdp']);
        $hache = password_hash($mot_de_passe, PASSWORD_DEFAULT);

        // Vérification de l'e-mail dans la table participant
        $tp = "SELECT * FROM participant WHERE email_participant = :destinataire";
        $requete = $bdd->prepare($tp);
        $requete->bindParam(':destinataire', $destinataire, PDO::PARAM_STR);
        $requete->execute();
        $rowCount = $requete->rowCount();

        if ($rowCount > 0) {
            // L'e-mail existe dans la table participant
            try {
                $majmdp = "UPDATE participant SET mot_de_passe_participant = :hache WHERE email_participant = :destinataire";
                $requeteMaj = $bdd->prepare($majmdp);
                $requeteMaj->bindParam(':hache', $hache, PDO::PARAM_STR);
                $requeteMaj->bindParam(':destinataire', $destinataire, PDO::PARAM_STR);
                $requeteMaj->execute();
                
                
                $majmdp = "UPDATE participant SET confirmation_mdp_participant = :hache WHERE email_participant = :destinataire";
                $requeteMaj = $bdd->prepare($majmdp);
                $requeteMaj->bindParam(':hache', $hache, PDO::PARAM_STR);
                $requeteMaj->bindParam(':destinataire', $destinataire, PDO::PARAM_STR);
                $requeteMaj->execute();
                
                
                
                
                echo "Mot de passe modifié avec succès !";
            } catch (PDOException $e) {
                echo $majMdp . "<br>" . $e->getMessage();
            }
        } else {
            // E-mail non trouvé dans la table participant
            echo "Email non trouvé dans la table participant";
        }
    }
} catch (PDOException $e) {
    echo "Erreur : " . $e->getMessage();
}

// Fermer la connexion
$bdd = null;

function securite($données)
{
    $données = trim($données);
    $données = stripslashes($données);
    $données = htmlspecialchars($données);
    return $données;
}
?>
