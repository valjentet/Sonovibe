<?php
$servername="localhost:3306";
$username="krcgrwhu";
$password="EzY2KRuspgwF9U";
// Connexion par PDO à la BDD
try{
    $bdd= new PDO("mysql:host=$servername;dbname=krcgrwhu_sonovibes",$username,$password);
    $bdd->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e){
    echo "Erreur : ".$e->getMessage();
} // On récupère les données par POST
if(isset($_POST['envoie'])){
    $prenom_participant=securite($_POST['prenom']);
    $nom_participant=securite($_POST['nom']);
    $email_participant=securite($_POST['mail']);
    $numero_de_tel_participant=securite($_POST['numero_tel']);
    $mot_de_passe_participant=securite($_POST['Password']);
    $confirmation_mdp_participant =securite($_POST['confirmation_mdp']);
    $mot_de_passe_hache = password_hash($mot_de_passe_participant, PASSWORD_DEFAULT);

    
    
    // On utilise une requête préparée puis on exécute.
    $stmt = $bdd->prepare("SELECT email_participant FROM participant WHERE email_participant = :email_participant");
    $stmt->bindParam(':email_participant', $email_participant, PDO::PARAM_STR);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Vérifiez si l'email existe déjà
    if ($result) {
        echo'<script>alert("Vous avez deja un compte avec cet email")</script>';
    }
    else {
        $requete= $bdd->prepare("INSERT INTO participant VALUES (0,:prenom_participant,:nom_participant,:email_participant,:numero_de_tel_participant,:mot_de_passe_participant,:confirmation_mdp_participant)");
        $requete->execute(
        array(
            'prenom_participant' => $prenom_participant,
            'nom_participant' => $nom_participant,
            'email_participant' => $email_participant,
            'numero_de_tel_participant' => $numero_de_tel_participant,
            'mot_de_passe_participant' => $mot_de_passe_hache,
            'confirmation_mdp_participant' => $mot_de_passe_hache
            )
        );
        
        sleep(3);
        header("Location: page_connexion.html"); // Redirection côté serveur après 3s
        exit();
    }


} // On évite les failles XMS
function securite($données) {
    $données = trim($données);
    $données = stripslashes($données);
    $données = htmlspecialchars($données);
    return $données;
}
// Auteur : Erwan Gingembre
?>
