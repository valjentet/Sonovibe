
document.addEventListener('DOMContentLoaded', function () {
    if (getCookie('save') === 'true') {
      document.getElementById('save').checked = true;
    }
  
  
    document.getElementById('save').addEventListener('change', function () {

      setCookie('save', this.checked, 30); // Le dernier paramètre est la durée en jours
    });
  });
  
  // Fonction pour définir un cookie
  function setCookie(name, value, days) {
    var expires = '';
    if (days) {
      var date = new Date();
      date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
      expires = '; expires=' + date.toUTCString();
    }
    document.cookie = name + '=' + value + expires + '; path=/';
  }
  
  // Fonction pour obtenir la valeur d'un cookie
  function getCookie(name) {
    var nameEQ = name + '=';
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == ' ') c = c.substring(1, c.length);
      if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
  }