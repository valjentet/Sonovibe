<!DOCTYPE html><!-- Auteur : Erwan Gingembre-->
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réinitialisation de mot de passe</title>
</head>
<body><!-- On écrit le mail qui sera affiché-->
    <p>Bonjour Madame, Monsieur,</p>
    echo '<p>Vous avez demandé la réinitialisation de votre mot de passe. Cliquez sur le lien ci-dessous pour procéder à la réinitialisation :   https://sonovibes.go.yj.fr/Connexion/newpassword.html;    

    <p>Si vous n'avez pas demandé cette réinitialisation, veuillez ignorer ce message.</p>
    <p>Cordialement,<br>
    L'équipe Sonosense, à bientôt !</p>
</body>
</html>
