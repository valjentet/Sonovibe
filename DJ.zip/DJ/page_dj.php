
<?php session_start(); ?>
<!DOCTYPE html>
<html>

<head>
    <style>
        body {
            background-color: #c8a2c8;
            margin: 0;
            font-family: Montserrat, sans-serif;
            color: black;
            padding: 0%;
        }

       h1 {
            color: #fff;
            text-align: center;
            padding: 20px;
            background-color: #58296f;
            margin: 0;
            display: flex;
            justify-content: center; /* Pour centrer horizontalement */
            align-items: center; /* Pour centrer verticalement */
       }
        


        .tabs {
            border: 1px solid black;
            display: flex;
        }

        .tabs__button[data-for-tab="1"] {
    margin-top: 20px; /* Ajoutez la marge que vous souhaitez */
}

        .tabs__sidebar {
            width: 200px;
            flex-shrink: 0;
            background: rgb(60, 59, 59);
            height: 750px;
            margin-top: 0px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .tabs__button {
            display: block;
            padding: 10px;
            background-color: #eee;
            border: none;
            width: 80%;
            outline: none;
            cursor: pointer;
            margin-bottom: 10px;
            border-radius: 10px;
        }

        .tabs__button:active {
            background: #58296f;
        }

        .tabs__button:not(:last-of-type) {
            border-bottom: 1px solid #ccc;
        }

        .tabs__button--active {
            font-weight: bold;
            border-right: 2px solid #58296f;
            background: #ddd;
            color: #58296f;
        }

        .tabs__content {
            padding: 20px;
            font: 500 16px/24px Montserrat, sans-serif;
            display: none;
            text-align: justify;
        }

        .tabs__content--active {
            display: block;
            max-width: 800px;
            margin: 20px auto;
        }

        .tabs__content>:first-child {
            margin-top: 0;
        }


        .suggestions {
            display: flex;
            flex-direction: column;
        }

        .suggestion {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
            background-color: rgba(255, 255, 255, 0.9);
            padding: 10px;
            border-radius: 10px;
        }

        .suggestion img {
            margin-right: 10px;
        }

        .suggestion-details {
            display: flex;
            flex-direction: column;
        }

        .suggestion-details p {
            margin: 5px 0; /* Ajustez la marge selon vos besoins */
        }

        .user {
            color: gray;
        }

        .paragraphe {
            text-align: justify;
            color:black;
        }

        .titre {
            color:black;
        }
    
        .img1 {
            border-radius: 20px;
            width: 100%;
            max-width: 400px;
            height: auto;
            display: block;
            margin: 0 auto;
        }   

        .details {
            margin-left: 20px; /* Adjust the margin as needed */
        }

        .detail-item {
            margin-bottom: 10px;
            display: flex;
            align-items: center;
        }

        .emoji {
            margin-right: 5px;
        }

        .text-overlay {
            margin-left: 20px; /* Adjust the margin as needed */
        }


        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 20px;
        }

        .img2 {
            width: 500px;
            height: 500px;
            border-radius: 20px;
        }

.button-container {
    display: flex;
    justify-content: center; 
    max-width: 100%; 
    overflow: auto; 
}

.button {
    display: flex;
    align-items: center;
    padding: 10px 20px;
    font-size: 16px;
    text-align: center;
    text-decoration: none;
    background-color: #58296f;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    margin: 0 10px; 
    max-width: 150px; 
    flex-shrink: 0; 
}

.logo {
    width: 30px;
    height: auto;
    margin-right: 5px;
}

.img3 {
    display: block;
    margin-top: 15px;
    max-width: 100%;
    height: auto;
    border-radius: 5px;
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
}

.volume-container {
    text-align: center;
    justify-content: center;
    
}

.volume-btn {
    background: none;
    border: none;
    cursor: pointer;
    
}

.volume-icon {
    display: inline-block;
    width: 20px;
    height: 20px;
    border-top: 10px solid transparent;
    border-bottom: 10px solid transparent;
    border-left: 15px solid #333;
    
}

.volume-slider {
    margin-top: 10px;
    
}

.volume-control-container {
    text-align: center;
}
body {
    font-family: 'Montserrat', sans-serif;
    margin: 0;
    background-color: #f7f7f7;
    color: #333;
}

h1 {
    color: #fff;
    text-align: center;
    padding: 20px;
    background-color: #58296f;
    margin: 0; 
} 

.titre {
    color: #333;
    text-align: center;
}

.tabs__content {
    max-width: 800px;
    margin: 20px auto;
    background-color: #fff;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.paragraphe {
    text-align: justify;
    line-height: 1.5;
}

.img3 {
    display: block;
    margin: 20px auto;
    width: 1000px; 
    max-width: 100%;
    height: 400px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}


.paragraphe + .paragraphe {
    margin-top: 15px;
}


.mini_titre{
    color: #58296f;
    margin-top: 20px;
}


.img-container {
    text-align: center;
}



/* barre de navigation */
body {
    padding: 0%;
    margin: 0%;
    font-family: Montserrat, sans-serif;
    color: black;
    
}

nav {
    background-color: white;
    color: black;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 0.7vh;
    padding-top: 0.7vh;
    box-shadow: 0 2px 5px grey;
    width: 100vw;
}
nav .a {
    text-decoration: none;
    color: black;   
    text-align: center;
    padding: 2vh 2.1vw;
}

.atextenav {
    font-size: 130%;
}

.middlesection {
    margin-left: 15vw;
}

nav .b {
    text-decoration: none;
    color: white;
    margin: 0 15px;
    text-align: center;
}

nav #right-section {
    display: flex;
    align-items: right;
}

nav button {
    margin-left: 15px;
    padding: 2vh;
    color: white;
    border: none;
    cursor: pointer;
}


.a:hover{
    background-color: rgb(196, 147, 196);
    border-radius: 8px;
}

.binscription{
    background-color: rgb(97, 15, 97);
    color: white;
    margin-right: 20px;
    font-size: 130%;
    border-radius: 10px;
}

.bconnexion {
    font-size: 130%;
    background-color: white;
    padding: 2vh;
}



#logonav {
    margin-left: 5%;
 }
@media screen and (max-width: 1400px) {

    nav .a {
        padding: 1vh 1.7vw;
        font-size: 0.8em;

    }
}


@media screen and (max-width: 1100px) {

    nav .a {
        padding: 0.8vh 1.5vw;
        font-size: 0.6em;

    }
    .binscription{
        font-size: 0.8em;
    }
}

@media screen and (max-width: 850px) {

    nav .a {
        padding: 0.6vh 1.3vw;
        font-size: 0.5em;

    }
    .binscription{
        font-size: 0.6em;
    }
}

@media screen and (max-width: 750px) {

    nav .a {
        padding: 0.5h 1.1vw;
        font-size: 0.4em;

    }
    .binscription{
        font-size: 0.4em;
    }
}
@media screen and (max-width: 600px) {

    nav .a {
        padding: 0.3h 0.7vw;
        font-size: 0.2em;

    }
    .binscription{
        font-size: 0.2em;
    }
    nav { box-shadow: none;}
}
@media screen and (max-width: 550px) {

    nav .a {
        padding: 0.2h 0.5w;
        font-size: 0.1em;

    }
    .binscription{
        font-size: 0.1em;
    }
}


@media screen and (min-width: 1700px) {

    nav .a {
        padding: 1.2h 1.9vw;
        font-size: 1em;

    }
    .binscription{
        font-size: 1em;
    }
}

@media screen and (min-width: 2400px) {

    nav .a {
        padding: 1.7h 2.3vw;
        font-size: 1.3em;

    }
    .binscription{
        font-size: 1em;
    }
}









        
    </style>
</head>

<body>
    <nav>
        <div name="logo" id="logonav">
          <a href="../Accueil/page_accueil.php"><img name="logo_sono" src="../Images/Sonovibes_logo.png" width="120" height="80"></a>
        </div>
        <div id="middle-section">
        <?php 
        if ($_SESSION['connecte'] == 1) {
            echo '
            <a href="../Accueil/page_accueil.php" class="a"> <span class="atextenav">Accueil</span></a>
            <a href="../Evenement/page_evenement.php" class="a"><b><span class="atextenav">Événements</span></b></a>
            <a href="../DJ/page_dj.php" class="a"><span class="atextenav">Page DJ</span></a>
            <a href="../Mon_compte/page_mon_compte.php" class="a"><span class="atextenav">Mon Compte</span></a>';
        } else {echo '
            <a href="../Nologin/Accueil/page_accueil.php" class="a"> <span class="atextenav">Accueil</span></a>
            <a href="../Nologin/Evenement/page_evenement.php" class="a"><b><span class="atextenav">Événements</span></b></a>
            <a href="../Nologin/DJ/page_dj.php" class="a"><span class="atextenav">Page DJ</span></a>
            <a href="../Nologin/Mon_compte/page_mon_compte.php" class="a"><span class="atextenav">Mon Compte</span></a>';
        }

        if ($_SESSION['roles'] == 1) {echo '    <a href="../Admin/dashboard_admin.php" class="a"><span class="atextenav">Administration</span></a> ';}
        ?>                
        </div>

        <div id="right-section">
            <?php 
        if ($_SESSION['connecte'] == 1) { 
            
            echo '<span class="a"> Bienvenue   ' . $_SESSION['prenom_participant'] . ' !      .</span>';
        } 
        else {
            echo '<button class="bconnexion"><a href="../Connexion/page_connexion.html" class="a">Connexion</a></button>
              <button class="binscription"><a href="../Connexion/page_inscription.html" class="b">Inscription</a></button>'; 
            
        }
        
                        ?>        </div>
    </nav>
        

        <div class="tabs">
            <div class="tabs__sidebar">
                <button class="tabs__button tabs__button--active" data-for-tab="1">Événement</button>
                <button class="tabs__button" data-for-tab="2">Votre Playlist</button>
                <button class="tabs__button" data-for-tab="3">Quelques Suggestions</button>
                <button class="tabs__button" data-for-tab="4">Données Capteurs</button>
            </div>

                        <?php
            $servername = "localhost:3306";
            $username = "krcgrwhu";
            $password="EzY2KRuspgwF9U";

            try {
                $bdd = new PDO("mysql:host=$servername;dbname=krcgrwhu_sonovibes", $username, $password);
                $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stmt = $bdd->prepare("SELECT * FROM evenement ORDER BY date_evenement ASC LIMIT 1");
                $stmt->execute();
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($result) {
                    $_SESSION['theme'] = $result['theme']; 
                } else {
                    echo "Aucun événement trouvé";
                }
            } catch (PDOException $e) {
                echo "Erreur : " . $e->getMessage();
            }
            ?>
            
            <div class="tabs__content tabs__content--active" data-tab="1">
                <h2 class="titre"><?php echo $result['nom_evenement']; ?></h2>
                <h3 class="mini_titre">Les détails de votre événement</h3>
                <div class="container">
                    <img src="../Images/photo_sasha/New-Years-Eve-at-OMNIA-Nightclub-San-Diego_-Photo-Credit_-Courtesy-of-Hakkasan-Group.jpg"
                        alt="" class="img1">
                    <div class="details">
                        <p class="detail-item"><span class="emoji">📅</span> <?php echo $result['date_evenement']; ?></p>
                        <p class="detail-item"><span class="emoji">⌚</span> <?php echo $result['heure_evenement']; ?></p>
                        <p class="detail-item"><span class="emoji">🏠</span> <?php echo $result['adresse_evenement']; ?></p>
                    </div>
                </div>
                <div class="text-overlay">
                    <p class="paragraphe"><?php echo $result['theme'];?> </p>
                </div>
            </div>

          
            <div class="tabs__content" data-tab="2">
                <h2 class="titre"><?php echo $result['nom_evenement']; ?></h2>
                <h3 class="mini_titre">Votre playlist</h3>
                <div class="container">
                    <img src="../Images/photo_sasha/photo_page.png" alt="" class="img2">
                    <div class="details">
                        
    <div class="button-container">
        <a href="https://open.spotify.com/" class="button" target="_blank">
            <img src="../Images/photo_sasha/spotify_logo_icon_206676.png" alt="Spotify Logo" class="logo">
            <span class="button-text">Spotify</span>
        </a>
        <a href="https://music.apple.com/us/browse" class="button" target="_blank">
            <img src="../Images/photo_sasha/apple-music-logo-4FBA5FADCC-seeklogo.com.png" alt="Apple Music Logo" class="logo">
            <span class="button-text">Apple Music</span>
        </a>
    </div>

    
    <div class="volume-control-container">
        <h3>Volume Control</h3>
        <div class="volume-slider-container">
            <input type="range" id="volumeSlider" class="volume-slider" value="50" min="0" max="100" step="1">
        </div>
    </div>
                <p class="paragraphe">
                    Connectez-vous à l'expérience musicale ultime en intégrant votre playlist directement depuis Spotify ou Apple Music. Partagez vos goûts musicaux préférés et personnalisez l'ambiance de notre soirée "Happy New Year". Il vous suffit de vous connecter à votre compte Spotify ou Apple Music, recherchez notre événement, et ajoutez vos morceaux préférés à la playlist collaborative. Ensemble, créons une symphonie qui marquera le début de cette nouvelle année. Plongez dans la magie de la musique et partagez vos hits incontournables pour que chaque note résonne avec l'énergie festive de la soirée. Connectez-vous et faites partie de la bande-son qui accompagnera cette célébration épique. Cheers to a Happy New Year filled with great tunes!
                </p>
            </div>
        </div>
            </div>
    
            <div class="tabs__content" data-tab="3">
                <h2 class="titre"><?php echo $result['nom_evenement']; ?></h2>
                <h3 class="mini_titre">Suggestions des participants</h3>
                <p class="paragraphe">Dans cette section dédiée de notre site, plongez au cœur de l'effervescence nocturne où les éclats de musique sont orchestrés par les suggestions émanant de votre public festif. Ici, les aspirations musicales prennent vie, tissant un fil conducteur entre les souhaits vibrants de nos invités et la pulsation rythmée de la soirée. Explorez avec passion cette galerie de recommandations, reflétant la diversité des goûts et des envies qui colorent nos nuits. Transformez ces suggestions en une symphonie envoûtante, créant une expérience sonore qui transcende les frontières du divertissement nocturne. En honorant les choix musicaux de notre auditoire, nous construisons un univers où la magie de la musique fusionne harmonieusement avec l'énergie palpitante de nos soirées, pour offrir des moments inoubliables au sein de notre boîte de nuit.</p>
                <div class="suggestions">
                    <div class="suggestion">
                        <img src="../Images/photo_sasha/istockphoto-1254454050-612x612.jpg" alt="" width="70px" height="50px">
                        <div class="suggestion-details">
                            <p class="text">Nom de la chanson by Chanteur</p>
                            <p class="user">Suggéré par Utilisateur9327</p>
                        </div>
                    </div>
                    <div class="suggestion">
                        <img src="../Images/photo_sasha/istockphoto-1254454050-612x612.jpg" alt="" width="70px" height="50px">
                        <div class="suggestion-details">
                            <p class="text">Nom de la chanson by Chanteur</p>
                            <p class="user">Suggéré par Utilisateur9327</p>
                        </div>
                    </div>
                    
                    <div class="suggestion">
                        <img src="../Images/photo_sasha/istockphoto-1254454050-612x612.jpg" alt="" width="70px" height="50px">
                        <div class="suggestion-details">
                            <p class="text">Nom de la chanson by Chanteur</p>
                            <p class="user">Suggéré par Utilisateur9327</p>
                        </div>
                    </div>
                    
                    <div class="suggestion">
                        <img src="../Images/photo_sasha/istockphoto-1254454050-612x612.jpg" alt="" width="70px" height="50px">
                        <div class="suggestion-details">
                            <p class="text">Nom de la chanson by Chanteur</p>
                            <p class="user">Suggéré par Utilisateur9327</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tabs__content" data-tab="4">
                <h2 class="titre"><?php echo $result['nom_evenement']; ?></h2>
                <h3 class="mini_titre">Données des capteurs sonores</h3>
            
                <p class="paragraphe">
                    Pour évaluer l'enthousiasme de votre public à l'égard de votre playlist, il est essentiel de jeter un coup d'œil aux données des capteurs sonores directement liés aux réactions sonores générées par l'audience dans la salle. Ces capteurs, intégrés de manière stratégique, captent en temps réel les variations et les nuances des réponses acoustiques du public, offrant ainsi des insights précieux sur l'impact de la musique diffusée. En analysant ces données, vous pourrez ajuster et optimiser votre sélection musicale, garantissant ainsi une expérience immersive et dynamique pour votre auditoire. L'intégration intelligente de la technologie des capteurs sonores permet d'aligner au mieux les préférences musicales de votre public, contribuant ainsi à l'élaboration d'une playlist véritablement captivante et adaptée à l'atmosphère de l'événement. Faites-nous vibrer!
                </p>
            
                <img src="../Images/photo_sasha/IMG_0187.jpg" alt="Event Image" width="300px" height="200px" class="img3">
            </div>

            
            

    
        <script>
            function setupTabs() {
                document.querySelectorAll(".tabs__button").forEach(button => {
                    button.addEventListener("click", () => {
                        const sideBar = button.parentElement;
                        const tabsContainer = sideBar.parentElement;
                        const tabNumber = button.dataset.forTab;
                        const tabToActivate = tabsContainer.querySelector(`.tabs__content[data-tab="${tabNumber}"]`);
    
                        sideBar.querySelectorAll(".tabs__button").forEach(button => {
                            button.classList.remove("tabs__button--active");
                        });
    
                        tabsContainer.querySelectorAll(".tabs__content").forEach(tab => {
                            tab.classList.remove("tabs__content--active");
                        });
    
                        button.classList.add("tabs__button--active");
                        tabToActivate.classList.add("tabs__content--active");
                    });
                });
            }
    
            document.addEventListener("DOMContentLoaded", () => {
                setupTabs();
            });
        </script>  
</body>

</html>